package com.example.cook_book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
